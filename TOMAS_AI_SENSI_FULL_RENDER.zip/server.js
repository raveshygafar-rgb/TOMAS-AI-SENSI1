import express from "express";
import OpenAI from "openai";
import path from "node:path";
import { fileURLToPath } from "node:url";

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const app = express();
app.disable("x-powered-by");
app.use(express.json({ limit: "20kb" }));
app.use(express.static(path.join(__dirname, "public"), { extensions: ["html"] }));

const port = process.env.PORT || 10000;
const apiKey = process.env.OPENAI_API_KEY;
const model = process.env.OPENAI_MODEL;
const client = apiKey ? new OpenAI({ apiKey }) : null;

app.get("/api/health", (_req, res) => {
  res.json({ ok: true, aiConfigured: Boolean(client && model), service: "TOMAS AI SENSI" });
});

app.post("/api/chat", async (req, res) => {
  try {
    if (!client || !model) {
      return res.status(503).json({ error: "هوش مصنوعی پیکربندی نشده است؛ OPENAI_API_KEY و OPENAI_MODEL را در Environment سرور تنظیم کن." });
    }
    const message = typeof req.body?.message === "string" ? req.body.message.trim() : "";
    if (!message || message.length > 4000) return res.status(400).json({ error: "پیام باید بین ۱ تا ۴۰۰۰ نویسه باشد." });

    const device = String(req.body?.device || "نامشخص").slice(0, 120);
    const style = String(req.body?.style || "head").slice(0, 30);
    const values = Array.isArray(req.body?.values)
      ? req.body.values.slice(0, 6).map(Number).filter(n => Number.isFinite(n) && n >= 0 && n <= 200)
      : [];

    const response = await client.responses.create({
      model,
      instructions: `You are TOMAS AI SENSI, a Persian-speaking Free Fire sensitivity and aim-training assistant.
Answer in Persian unless asked otherwise. Help only with legitimate in-game settings and practice.
Never promise guaranteed headshots. Sensitivity values are starting points and depend on device, FPS, screen, grip, and player.
Device: ${device}. Play style: ${style}. Current sensitivity values: ${values.join(", ") || "not supplied"}.
Give practical, concise advice. Never request, reveal, or repeat API keys.`,
      input: message
    });
    res.json({ reply: response.output_text || "پاسخی دریافت نشد." });
  } catch (err) {
    console.error("OpenAI request failed:", err?.status || err?.message || "unknown error");
    res.status(502).json({ error: "پاسخ هوش مصنوعی دریافت نشد؛ نام مدل، دسترسی API و گزارش‌های سرور را بررسی کن." });
  }
});

app.listen(port, "0.0.0.0", () => console.log(`TOMAS listening on ${port}`));
